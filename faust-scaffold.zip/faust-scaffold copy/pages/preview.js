import { WordPressTemplate } from '@faustwp/core';

export default function Preview(props) {
  return <WordPressTemplate {...props} />;
}
