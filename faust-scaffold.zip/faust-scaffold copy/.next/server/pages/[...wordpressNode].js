"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/[...wordpressNode]";
exports.ids = ["pages/[...wordpressNode]"];
exports.modules = {

/***/ "./pages/[...wordpressNode].js":
/*!*************************************!*\
  !*** ./pages/[...wordpressNode].js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Page),\n/* harmony export */   \"getStaticPaths\": () => (/* binding */ getStaticPaths),\n/* harmony export */   \"getStaticProps\": () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @faustwp/core */ \"@faustwp/core\");\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Page(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.WordPressTemplate, {\n        ...props\n    }, void 0, false, {\n        fileName: \"/Users/teresa.gobble/Desktop/portfolio-testing/faust-scaffold/pages/[...wordpressNode].js\",\n        lineNumber: 4,\n        columnNumber: 10\n    }, this);\n}\nfunction getStaticProps(ctx) {\n    return (0,_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.getWordPressProps)({\n        ctx\n    });\n}\nasync function getStaticPaths() {\n    return {\n        paths: [],\n        fallback: \"blocking\"\n    };\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9bLi4ud29yZHByZXNzTm9kZV0uanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBcUU7QUFFdEQsU0FBU0UsS0FBS0MsS0FBSyxFQUFFO0lBQ2xDLHFCQUFPLDhEQUFDRiw0REFBaUJBO1FBQUUsR0FBR0UsS0FBSzs7Ozs7O0FBQ3JDLENBQUM7QUFFTSxTQUFTQyxlQUFlQyxHQUFHLEVBQUU7SUFDbEMsT0FBT0wsZ0VBQWlCQSxDQUFDO1FBQUVLO0lBQUk7QUFDakMsQ0FBQztBQUVNLGVBQWVDLGlCQUFpQjtJQUNyQyxPQUFPO1FBQ0xDLE9BQU8sRUFBRTtRQUNUQyxVQUFVO0lBQ1o7QUFDRixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGZhdXN0d3AvZmF1c3Qtc2NhZmZvbGQvLi9wYWdlcy9bLi4ud29yZHByZXNzTm9kZV0uanM/MzVmYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRXb3JkUHJlc3NQcm9wcywgV29yZFByZXNzVGVtcGxhdGUgfSBmcm9tICdAZmF1c3R3cC9jb3JlJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnZShwcm9wcykge1xuICByZXR1cm4gPFdvcmRQcmVzc1RlbXBsYXRlIHsuLi5wcm9wc30gLz47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdGF0aWNQcm9wcyhjdHgpIHtcbiAgcmV0dXJuIGdldFdvcmRQcmVzc1Byb3BzKHsgY3R4IH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUGF0aHMoKSB7XG4gIHJldHVybiB7XG4gICAgcGF0aHM6IFtdLFxuICAgIGZhbGxiYWNrOiAnYmxvY2tpbmcnLFxuICB9O1xufVxuIl0sIm5hbWVzIjpbImdldFdvcmRQcmVzc1Byb3BzIiwiV29yZFByZXNzVGVtcGxhdGUiLCJQYWdlIiwicHJvcHMiLCJnZXRTdGF0aWNQcm9wcyIsImN0eCIsImdldFN0YXRpY1BhdGhzIiwicGF0aHMiLCJmYWxsYmFjayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/[...wordpressNode].js\n");

/***/ }),

/***/ "@faustwp/core":
/*!********************************!*\
  !*** external "@faustwp/core" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("@faustwp/core");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/[...wordpressNode].js"));
module.exports = __webpack_exports__;

})();