"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Page),\n/* harmony export */   \"getStaticProps\": () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @faustwp/core */ \"@faustwp/core\");\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Page(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.WordPressTemplate, {\n        ...props\n    }, void 0, false, {\n        fileName: \"/Users/teresa.gobble/Desktop/portfolio-testing/faust-scaffold/pages/index.js\",\n        lineNumber: 4,\n        columnNumber: 10\n    }, this);\n}\nfunction getStaticProps(ctx) {\n    return (0,_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.getWordPressProps)({\n        ctx\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQXFFO0FBRXRELFNBQVNFLEtBQUtDLEtBQUssRUFBRTtJQUNsQyxxQkFBTyw4REFBQ0YsNERBQWlCQTtRQUFFLEdBQUdFLEtBQUs7Ozs7OztBQUNyQyxDQUFDO0FBRU0sU0FBU0MsZUFBZUMsR0FBRyxFQUFFO0lBQ2xDLE9BQU9MLGdFQUFpQkEsQ0FBQztRQUFFSztJQUFJO0FBQ2pDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AZmF1c3R3cC9mYXVzdC1zY2FmZm9sZC8uL3BhZ2VzL2luZGV4LmpzP2JlZTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0V29yZFByZXNzUHJvcHMsIFdvcmRQcmVzc1RlbXBsYXRlIH0gZnJvbSAnQGZhdXN0d3AvY29yZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBhZ2UocHJvcHMpIHtcbiAgcmV0dXJuIDxXb3JkUHJlc3NUZW1wbGF0ZSB7Li4ucHJvcHN9IC8+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoY3R4KSB7XG4gIHJldHVybiBnZXRXb3JkUHJlc3NQcm9wcyh7IGN0eCB9KTtcbn1cbiJdLCJuYW1lcyI6WyJnZXRXb3JkUHJlc3NQcm9wcyIsIldvcmRQcmVzc1RlbXBsYXRlIiwiUGFnZSIsInByb3BzIiwiZ2V0U3RhdGljUHJvcHMiLCJjdHgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "@faustwp/core":
/*!********************************!*\
  !*** external "@faustwp/core" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("@faustwp/core");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();